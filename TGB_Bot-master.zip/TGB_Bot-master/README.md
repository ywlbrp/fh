This is the bot created by me on the playlist "How To Make A Discord Bot - 2021" on my youtube channel https://www.youtube.com/channel/UC2L1Ot4Ba40DMDLV0ryzFkw
